Clear Opening Web App

Files:
- index.html
- manifest.json
- sw.js

How to use:
1. Put all files in the same folder.
2. Open index.html to test it.
3. Host the folder on a web server over HTTPS to install it like a phone app.

This version uses plain HTML, CSS, and JavaScript.
